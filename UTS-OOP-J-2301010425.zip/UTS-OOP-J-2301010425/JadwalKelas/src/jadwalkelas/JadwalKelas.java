/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jadwalkelas;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author MyBook Hype
 */
public class JadwalKelas {
    static Scanner input = new Scanner(System.in);
    static MataKuliah[] daftarMK = new MataKuliah[100];
    static int jumlah = 0;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int pilih;
        do {
            System.out.println("\n=== Menu Aplikasi Mata Kuliah ===");
            System.out.println("1. Tambah Mata Kuliah");
            System.out.println("2. Tampilkan Semua Mata Kuliah");
            System.out.println("3. Ubah Mata Kuliah");
            System.out.println("4. Hapus Mata Kuliah");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu (1/2/3/4/5): ");
            //pilih = input.nextInt();
            //input.nextLine();
            try {
                pilih = input.nextInt();
                input.nextLine();
            } catch (Exception e){
                System.out.println ("Input Harus Angka!");
                return;
            }

            switch (pilih) {
                case 1 -> tambah();
                case 2 -> tampil();
                case 3 -> ubah();
                case 4 -> hapus();
                case 5 -> System.out.println("Sampai Jumpa Lagiii.......");
                default -> System.out.println("Menu tidak tersedia.");
            }
        } while (pilih != 5);
    }

    public static void tambah() {
        System.out.print("Nama Mata Kuliah: ");
        String nama = input.nextLine();
        System.out.print("Hari Perkuliahan: ");
        String hari = input.nextLine();
        System.out.print("Jumlah SKS: ");
        int sks ;
        try {
            sks = input.nextInt();
            input.nextLine(); // Buang newline agar aman
        } catch (InputMismatchException e) {
            System.out.println("Input tidak valid! Masukkan angka.");
            input.nextLine(); // Buang input salah
            return; // Keluar dari fungsi tambah()
        }
        //input.nextLine();
        System.out.print("Apakah ini mata kuliah pilihan? (y/n): ");
        String pilihan = input.nextLine();

        if (pilihan.equalsIgnoreCase("y")) {
            daftarMK[jumlah] = new MataKuliahPilihan(nama, hari, sks);
        } else {
            daftarMK[jumlah] = new MataKuliah(nama, hari, sks);
        }

        jumlah++;
        System.out.println("Mata kuliah berhasil ditambahkan.");
    }

    public static void tampil() {
        if (jumlah == 0) {
            System.out.println("Belum ada mata kuliah.");
        } else {
            for (int i = 0; i < jumlah; i++) {
                System.out.print((i + 1) + ". ");
                daftarMK[i].tampilkan();
                System.out.println();
            }
        }
    }

    public static void ubah() {
        
        tampil();
        System.out.print("Nomor yang ingin diubah: ");
        int i = input.nextInt() - 1;
        input.nextLine();

        if (i >= 0 && i < jumlah) {
            System.out.print("Nama baru: ");
            String nama = input.nextLine();
            System.out.print("Hari baru: ");
            String hari = input.nextLine();
            System.out.print("SKS baru: ");
            int sks = input.nextInt();
            input.nextLine();
            
            daftarMK[i].setNama(nama);
            daftarMK[i].setSks(sks);
            daftarMK[i].setHari(hari);
            System.out.println("Data berhasil diubah.");
        } else {
            System.out.println("Nomor tidak valid.");
        }
    }

    public static void hapus() {
        tampil();
        System.out.print("Nomor yang ingin dihapus: ");
        int i = input.nextInt() - 1;
        input.nextLine();

        if (i >= 0 && i < jumlah) {
            for (int j = i; j < jumlah - 1; j++) {
                daftarMK[j] = daftarMK[j + 1];
            }
            daftarMK[jumlah - 1] = null;
            jumlah--;
            System.out.println("Data berhasil dihapus.");
        } else {
            System.out.println("Nomor tidak valid.");
        }
    }
    
}
