/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jadwalkelas;

/**
 *
 * @author MyBook Hype
 */
public class MataKuliah {
    private String nama;
    private String hari;
    private int sks;

    public MataKuliah(String nama,String hari, int sks) {
        this.nama = nama;
        this.hari = hari;
        this.sks = sks;
    }

    public String getNama() {
        return nama;
    }
    public String getHari() {
        return hari;
    }
    public int getSks() {
        return sks;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    public void setHari(String hari) {
        this.hari = hari;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }

    public void tampilkan() {
        System.out.printf("Nama MataKuliah: " + nama +"| Hari: " + hari + "| SKS: " + sks);
    }
}
