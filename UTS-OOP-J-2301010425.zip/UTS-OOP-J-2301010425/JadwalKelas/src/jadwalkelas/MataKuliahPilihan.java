/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jadwalkelas;

/**
 *
 * @author MyBook Hype
 */
public class MataKuliahPilihan extends MataKuliah {
    public MataKuliahPilihan(String nama,String hari, int sks) {
        super(nama,hari, sks);
    }

    /**
     *
     */
    @Override
    public void tampilkan() {

        System.out.println( "Nama MataKuliah: " + getNama() +" | " + "Hari: " + getHari() + " | " + "SKS: " + getSks() + " SKS|" + "[PILIHAN] ");
    }
}
